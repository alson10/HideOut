<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Shopping Cart</title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/dulaypartyneeds.png')); ?>" type="">
    <!-- Include Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Include Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>
<body>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Shopping Cart')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="container mt-4">
        <?php if($cartItems && count($cartItems) > 0): ?>
            <div class="row justify-content-center"> <!-- Center the content -->
                <div class="col-md-10"> <!-- Adjust the column width -->
                    <div class="table-responsive"> <!-- Make the table responsive -->
                        <table class="table">
                            
                            <thead>
                                <tr>
                                    <!-- <th>Select</th> -->
                                    
                                    <th>Image</th>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total Amount</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $totalPrice = 0; // Initialize the total price variable
                            ?>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <!-- <td>
                                            <input type="checkbox" name="selected_items[]" value="<?php echo e($cartItem->id); ?>">
                                        </td> -->
                                        <td>
                                            <?php if($cartItem->product): ?>
                                                <img src="<?php echo e(asset('storage/' . $cartItem->product->image_path)); ?>" alt="<?php echo e($cartItem->product->name); ?>" style="max-width: 80px; max-height: 80px;">
                                            <?php else: ?>
                                                Product not available (ID: <?php echo e($cartItem->product_id); ?>)
                                            <?php endif; ?>
                                        </td>
                                        <td><b><?php echo e(optional($cartItem->product)->name); ?></b></td>
                                        <td>
                                            <?php if($cartItem->product): ?>
                                                ₱<?php echo e($cartItem->product->price); ?>

                                            <?php else: ?>
                                                Product not available
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <!-- <input type="number" value="<?php echo e($cartItem->quantity); ?>" min="1"> -->
                                            <?php if($cartItem->quantity): ?>
                                                <?php echo e($cartItem->quantity); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($cartItem->product): ?>
                                                ₱<?php echo e($cartItem->quantity * $cartItem->product->price); ?>

                                            <?php else: ?>
                                                N/A
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="#" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#updateModal_<?php echo e($cartItem->id); ?>">
                                                Update
                                            </a>
                                            <div class="modal fade" id="updateModal_<?php echo e($cartItem->id); ?>" tabindex="-1" aria-labelledby="updateModalLabel_<?php echo e($cartItem->id); ?>" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="updateModalLabel_<?php echo e($cartItem->id); ?>">Update Quantity</h5>
                                                            <button class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('cart.update', $cartItem->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PATCH'); ?>
                                                                <label for="quantity">New Quantity:</label>
                                                                <input type="number" name="quantity" id="quantity" value="<?php echo e($cartItem->quantity); ?>" min="1">
                                                                <button class="btn btn-primary">Update</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <a href="<?php echo e(route('cart.remove', $cartItem)); ?>" class="btn btn-danger btn-sm">Remove</a>
                                        </td>
                                        <?php
                                            $productTotal = $cartItem->quantity * $cartItem->product->price;
                                            $totalPrice += $productTotal; // Calculate total price
                                        ?>
                                    </tr>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <th>Total:</th>
                                        <th><h1> ₱<?php echo e($totalPrice); ?></h1></th>
                                        <td> 
                                            <div class="container">
                                                <input type="hidden" name="total_price" value="<?php echo e($totalPrice); ?>">
                                                
                                                <button class="btn btn-warning btn-sm" id="checkoutButton" data-bs-toggle="modal" data-bs-target="#firstCheckoutModal">Checkout</button>

                                            </div>
                                            <!-- review order modal -->
                                            <div class="modal fade" id="firstCheckoutModal" tabindex="-1" aria-labelledby="firstCheckoutModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="firstCheckoutModalLabel">Checkout</h5>
                                                            <button class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                        <table class="table">
                                                            <thead>
                                                                <tr>
                                                                    <th>Image</th>
                                                                    <th>Product</th>
                                                                    <th>Price</th>
                                                                    <th>Quantity</th>
                                                                    <th>Total Amount</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <tr>
                                                                        <td>
                                                                            <?php if($cartItem->product): ?>
                                                                                <img src="<?php echo e(asset('storage/' . $cartItem->product->image_path)); ?>" alt="<?php echo e($cartItem->product->name); ?>" style="max-width: 80px; max-height: 80px;">
                                                                            <?php else: ?>
                                                                                Product not available (ID: <?php echo e($cartItem->product_id); ?>)
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td><b><?php echo e(optional($cartItem->product)->name); ?></b></td>
                                                                        <td>
                                                                            <?php if($cartItem->product): ?>
                                                                                ₱<?php echo e($cartItem->product->price); ?>

                                                                            <?php else: ?>
                                                                                Product not available
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td>
                                                                            <?php if($cartItem->quantity): ?>
                                                                                <?php echo e($cartItem->quantity); ?>

                                                                            <?php else: ?>
                                                                                N/A
                                                                            <?php endif; ?>
                                                                        </td>
                                                                        <td>
                                                                            <?php if($cartItem->product): ?>
                                                                                ₱<?php echo e($cartItem->quantity * $cartItem->product->price); ?>

                                                                            <?php else: ?>
                                                                                N/A
                                                                            <?php endif; ?>
                                                                        </td>
                                                                    </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <th>Total:</th>
                                                                    <th>₱<?php echo e($totalPrice); ?></th>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <p>Please review your order before proceeding to checkout.</p>
                                                            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#checkoutModal">Continue to Checkout</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- main modal-->
                                            <div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="checkoutModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="checkoutModalLabel">Checkout</h5>
                                                            <button class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <form action="<?php echo e(route('orders.store')); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="mb-3">
                                                                    <label for="delivery" class="form-label">Payment Method</label> <br>
                                                                    <select name="delivery" id="delivery">
                                                                        <option value="pick-up">Pick-Up</option>
                                                                        <option value="cod">COD</option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="address" class="form-label">Address(for COD only)</label>
                                                                    <input type="text" class="form-control" id="address" name="address" placeholder="House no., Street Name, Barangay, Town/City">
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="contact" class="form-label">Contact no</label>
                                                                    <input type="number" class="form-control" id="contact" name="contact" placeholder="ex. 09123456789" required>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label for="message" class="form-label">Message(optional)</label>
                                                                    <input type="text" class="form-control" id="message" name="message" placeholder="leave a message or instruction">
                                                                </div>
                                                                
                                                                <button class="btn btn-primary">Complete Checkout</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="alert alert-info text-center">
                Your shopping cart is empty.
            </div>
        <?php endif; ?>
    </div>

    <!-- Include Bootstrap JS (Optional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Include Font Awesome JS (Optional) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
    

  
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<footer class="text-white text-center text-lg-start bg-dark">
    <!-- Grid container -->
    <div class="container p-4">
      <!--Grid row-->
      <div class="row mt-4">
        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">About company</h5>

          <p>
          <b>Dulay Party Needs</b> is your all-in-one destination for celebration essentials. From delectable cakes to vibrant balloons, we've got you covered. Explore curated packages for special occasions like Valentine's Day, ensuring your moments are effortlessly extraordinary. 
          </p>

          <p>
          Celebrate with quality products and thoughtful curation at Dulay Party Needs, where every detail is designed to make your festivities memorable.
          </p>

          <!-- <div class="mt-4">
            
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-facebook-f"></i></a>
            
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-dribbble"></i></a>
            
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-twitter"></i></a>
            
            <a type="button" class="btn btn-floating btn-light btn-lg"><i class="fab fa-google-plus-g"></i></a>
            
          </div> -->
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <ul class="fa-ul" style="margin-left: 1.65em;">
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-home"></i></span><span class="ms-2">Municipal St, San Nicolas, Pangasinan</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-envelope"></i></span><span class="ms-2">dulaypartyneeds@gmail.com</span>
            </li>
            <li class="mb-3">
              <span class="fa-li"><i class="fas fa-phone"></i></span><span class="ms-2">0920 741 1367</span>
            </li>
          </ul>
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-4 mb-md-0">
          <h5 class="text-uppercase mb-4">Physical Store Opening hours</h5>

          <table class="table text-center text-white">
            <tbody class="fw-normal">
              <tr>
                <td>Mon - Thu:</td>
                <td>8am - 5pm</td>
              </tr>
              <tr>
                <td>Fri - Sat:</td>
                <td>8am - 5pm</td>
              </tr>
              <tr>
                <td>Sunday:</td>
                <td>Close</td>
              </tr>
            </tbody>
          </table>
        </div>
        <!--Grid column-->
      </div>
      <!--Grid row-->
    </div>
    <!-- Grid container -->

    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
      © 2023 Copyright:
      <a class="text-white" href="#">Buca Company</a>
    </div>
    <!-- Copyright -->
  </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\midterm-sia\dulayPartyNeeds\resources\views/cart/index.blade.php ENDPATH**/ ?>