
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/dulaypartyneeds.png')); ?>" type="">
        <!-- Include Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <!-- Include Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>
<body>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Products')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-8xl mx-auto sm:px-6 lg:px-8">
            <div class="flex justify-between items-center mb-4">
                <a href="<?php echo e(route('products.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-lg inline-block" style="background-color: blue;color: white; padding: 10px;">+ Product</a>

                <?php if(session('success')): ?>
                    <div class="bg-green-100 border-green-200 text-green-700 rounded-lg px-4 py-2" >
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
            </div>
            <div class="bg-white dark:bg-gray-800 rounded-lg shadow">
            
            <div class="p-6">
                    <div class="flex justify-between mb-4">
                        <h3 class="text-lg font-semibold ">Product List</h3>
                        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="flex">
                            <select name="month" class="mr-2">
                                <option value="">Select Month</option>
                                <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($month); ?>" <?php echo e(Request::input('month') == $month ? 'selected' : ''); ?>>
                                        <?php echo e(date('F', mktime(0, 0, 0, $month, 1))); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <select name="year" class="mr-2">
                                <option value="">Select Year</option>
                                <?php $__currentLoopData = range(date('Y'), date('Y')+20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year); ?>" <?php echo e(Request::input('year') == $year ? 'selected' : ''); ?>>
                                        <?php echo e($year); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="text" name="search" placeholder="Search..." class="mr-2" value="<?php echo e(Request::input('search')); ?>">
                            <button type="submit" class="bg-blue-500 px-4 py-2 rounded-lg">Search</button>
                        </form>
                    </div>
        <?php if($products->count() > 0): ?>
        
        <table class="w-full border border-gray-200">
            <thead>
                <tr>
                <th class="px-4 py-2 bg-gray-100 border">Image</th>
                    <th class="px-4 py-2 bg-gray-100 border">Name</th>
                    <th class="px-4 py-2 bg-gray-100 border">Description</th>
                    <th class="px-4 py-2 bg-gray-100 border">Price</th>
                    <th class="px-4 py-2 bg-gray-100 border">Category</th>
                    <th class="px-4 py-2 bg-gray-100 border">Stock</th>
                    <th class="px-4 py-2 bg-gray-100 border">Date Added</th>
                    <th class="px-4 py-2 bg-gray-100 border">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-center">
                        <td class="px-4 py-2 border">
                            <center>
                            <img src="<?php echo e(asset('storage/' . $item->image_path)); ?>" style="max-width: 100px; height: auto;">

                            </center>
                        </td>
                        <td class="px-4 py-2 border"><?php echo e($item->name); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($item->description); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($item->price); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($item->category); ?></td>
                        <td class="px-4 py-2 border"><?php echo e($item->quantity); ?></td>
                        <td class="px-4 py-2 border"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('F d, Y')); ?></td>
                        
                        <td class="px-4 py-2 border">
                            <div class="d-flex justify-content-between">
                                <div class="col">
                                    <a href="<?php echo e(route('products.edit', $item->id)); ?>" class="btn btn-primary">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </div>
                                <div class="col">
                                    <form action="<?php echo e(route('products.destroy', $item->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="mt-4">
                            <?php echo e($products->links()); ?>

                        </div>
                    <?php else: ?>
                        <h5>You have no products</h5>
                    <?php endif; ?>
                </div>
            </div>
        </div>   
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel3b\hideOut\resources\views/products/index.blade.php ENDPATH**/ ?>