<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="<?php echo e(asset('assets/images/dulaypartyneeds.png')); ?>" type="">
      <title>Dulay Party Needs</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>" />
      <!-- font awesome style -->
      <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet" />
      <!-- responsive style -->
      <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet" />
   </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
         <header class="header_section">
            <div class="container">
               <nav class="navbar sticky-top navbar-expand-sm custom_nav-container ">
                  <a class="navbar-brand" href="#"><img width="100" src="<?php echo e(asset('assets/images/bilog_logo.png')); ?>" alt="#" /></a>
                  <!-- <h2>Dulay Party Needs</h2>s -->
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class=""> </span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                     <ul class="navbar-nav">
                        <!-- <li class="nav-item active">
                           <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#productsec">Products</a>
                        </li>
                        <li class="nav-item">
                           <a class="nav-link" href="#footersec">Contact</a>
                        </li>
                        | -->
                        <li class="nav-item">
                           <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>|
                        <li class="nav-item">
                           <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                        </li>
                     </ul>
                  </div>
               </nav>
            </div>
         </header>
         <!-- end header section -->
         <!-- slider section -->
         <section class="slider_section ">
            <div class="slider_bg_box">
               <img src="<?php echo e(asset('assets/images/image-2.jpg')); ?>" alt="">
            </div>
            <div id="customCarousel1" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <div class="container ">
                        <div class="row">
                           <div class="col-md-7 col-lg-6 ">
                              <!-- <div class="detail-box">
                                 <h1>
                                    <span>
                                    Welcome to,
                                    </span>
                                    <br>
                                    Dulay Party Needs
                                 </h1>
                                 <p>
                                 San Nicolas, Pangasinan
                                 </p>
                                 <div class="btn-box">
                                    <a href="<?php echo e(route('login')); ?>" class="btn1">
                                    Shop Now
                                    </a>
                                 </div>
                              </div> -->
                           </div>
                        </div>
                     </div>
                  </div>
            </div>
         </section>
         <!-- end slider section -->
      </div>
      <!-- why section -->
      
      <!-- end why section -->
      
      <!-- arrival section -->
      <section class="arrival_section">
         <div class="container">
            <div class="box">
               <div class="arrival_bg_box">
                  <img src="<?php echo e(asset('assets/images/image-3.jpg')); ?>" alt="">
               </div>
               <div class="row">
                  <div class="col-md-6 ml-auto">
                     <div class="heading_container remove_line_bt">
                        <h2>
                           About us
                        </h2>
                     </div>
                     <p style="margin-top: 20px;margin-bottom: 30px; text-align:justify">
                     <b>Hideout Resto Bar</b> invites you to embark on a culinary journey where exquisite flavors meet a vibrant ambiance. Our establishment is your haven for delightful evenings, offering a diverse menu of mouthwatering dishes and handcrafted cocktails. Whether you're seeking a cozy spot for a romantic dinner or a lively atmosphere to unwind with friends, Hideout Resto Bar caters to every occasion. Indulge in the perfect blend of exceptional cuisine and an inviting setting, making each visit a memorable escape. Join us at Hideout Resto Bar, where every moment is an opportunity to savor the essence of good food and great company.
                     </p>
                     <a href="<?php echo e(route('login')); ?>">
                     JOIN US
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- end arrival section -->
      
   <!-- product section -->
<section class="product_section layout_padding" id="productsec">
    <div class="container">
        <div class="heading_container heading_center">
            <h2>Our <span>packages</span></h2>
        </div>
        <div class="row">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="box">
                        <div class="img-box">
                            <img src="<?php echo e(asset('storage/' . $package->image_path)); ?>" alt="<?php echo e($package->name); ?>">
                        </div>
                        <div class="detail-box">
                            <h5><?php echo e($package->name); ?></h5>
                            <h6>₱<?php echo e($package->price); ?></h6>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="btn-box">
            <a href="<?php echo e(route('login')); ?>">View All products</a>
        </div>
    </div>
</section>
<!-- end product section -->

      <!-- footer start -->
      <footer>
         <div class="container" id="footersec">
            <div class="row">
               <div class="col-md-4">
                   <div class="full">
                      <div class="logo_footer">
                        <a href="#"><img width="150" src="<?php echo e(asset('assets/images/bilog_logo.png')); ?>" alt="#" /></a>
                      </div>
                      <div class="information_f">
                        <p><strong>ADDRESS:</strong> 237 Carmen - Alcala Rd, Santo Tomas, 2441 Pangasinan, 2426</p>
                        <p><strong>TELEPHONE:</strong> 0907 426 5482</p>
                        <p><strong>EMAIL:</strong> hideout@gmail.com</p>
                      </div>
                   </div>
               </div>
               <div class="col-md-8">
                  <div class="row">
                  <div class="col-md-7">
                     <div class="row">
                        <div class="col-md-6">
                     <div class="widget_menu">
                        <h3>Menu</h3>
                        <ul>
                           <li><a href="#">Home</a></li>
                           <li><a href="#">About</a></li>
                           <li><a href="#">Services</a></li>
                           <li><a href="#">Testimonial</a></li>
                           <li><a href="#">Blog</a></li>
                           <li><a href="#">Contact</a></li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-md-6">
                     <div class="widget_menu">
                        <h3>Account</h3>
                        <ul>
                           <li><a href="#">Account</a></li>
                           <li><a href="#">Checkout</a></li>
                           <li><a href="#">Login</a></li>
                           <li><a href="#">Register</a></li>
                           <li><a href="#">Shopping</a></li>
                           <li><a href="#">Widget</a></li>
                        </ul>
                     </div>
                  </div>
                     </div>
                  </div>     
                  <div class="col-md-5">
                     <div class="widget_menu">
                        <h3>Newsletter</h3>
                        <div class="information_f">
                          <p>Subscribe by our newsletter and get update protidin.</p>
                        </div>
                        <div class="form_sub">
                           <form>
                              <fieldset>
                                 <div class="field">
                                    <input type="email" placeholder="Enter Your Mail" name="email" />
                                    <input type="submit" value="Subscribe" />
                                 </div>
                              </fieldset>
                           </form>
                        </div>
                     </div>
                  </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
      <!-- footer end -->
      <div class="cpy_">
         <p class="mx-auto">© 2023 All Rights Reserved By <a href="https://html.design/">Hide Out</a><br>
         </p>
      </div>
      <!-- jQery -->
      <script src="js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="js/custom.js"></script>
   </body>
</html><?php /**PATH C:\xampp\htdocs\laravel3b\HideOut\hideOut\resources\views/welcome.blade.php ENDPATH**/ ?>